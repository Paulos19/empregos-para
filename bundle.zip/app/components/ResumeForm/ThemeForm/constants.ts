export const THEME_COLORS = [
  "#f87171",
  "#ef4444",
  "#fb923c",
  "#f97316",
  "#fbbf24",
  "#f59e0b",
  "#22c55e",
  "#15803d",
  "#38bdf8",
  "#0ea5e9",
  "#818cf8",
  "#6366f1",
];
