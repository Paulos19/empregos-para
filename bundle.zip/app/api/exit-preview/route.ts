import { exitPreview } from "@prismicio/next";

export function GET() {
  return exitPreview();
}
